<?php
/**
 * Il file base di configurazione di WordPress.
 *
 * Questo file viene utilizzato, durante l’installazione, dallo script
 * di creazione di wp-config.php. Non è necessario utilizzarlo solo via web
 * puoi copiare questo file in «wp-config.php» e riempire i valori corretti.
 *
 * Questo file definisce le seguenti configurazioni:
 *
 * * Impostazioni del database
 * * Chiavi segrete
 * * Prefisso della tabella
 * * ABSPATH
 *
 * * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Impostazioni database - È possibile ottenere queste informazioni dal proprio fornitore di hosting ** //
/** Il nome del database di WordPress */
define( 'DB_NAME', 'primosito1' );

/** Nome utente del database */
define( 'DB_USER', 'root' );

/** Password del database */
define( 'DB_PASSWORD', '' );

/** Hostname del database */
define( 'DB_HOST', 'localhost' );

/** Charset del Database da utilizzare nella creazione delle tabelle. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Il tipo di collazione del database. Da non modificare se non si ha idea di cosa sia. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chiavi univoche di autenticazione e di sicurezza.
 *
 * Modificarle con frasi univoche differenti!
 * È possibile generare tali chiavi utilizzando {@link https://api.wordpress.org/secret-key/1.1/salt/ servizio di chiavi-segrete di WordPress.org}
 *
 * È possibile cambiare queste chiavi in qualsiasi momento, per invalidare tutti i cookie esistenti.
 * Ciò forzerà tutti gli utenti a effettuare nuovamente l'accesso.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'tT c@}0g6s44B{ERX,DZfAa}PC*MEL@ICaryLxfcZ;6HpQ=DKQT(F)<Z]@6Vv{F~' );
define( 'SECURE_AUTH_KEY',  'df!I9330[TtarcWMXM1.g>re/KcL<L/wt$CC6x~g+A:/a5U[E|/god1ljiWbj+1i' );
define( 'LOGGED_IN_KEY',    'dR`~yy13vDhUOwD1`H$e_L=g.R>$_fx3Q*MOZGIPro3xMvfA3;s!.TI*4Nx9)OvB' );
define( 'NONCE_KEY',        '1fEJ2_=c_kzmwYm*42W6Osd@c$qftwk;ZvC+!tug}~n?[#:D(<ytU)+g9<.p;+re' );
define( 'AUTH_SALT',        'f:odQ9QL<`a`,O@[X+`~*r9*Zw6kro*/x&K{Dnko?U5Q11,cP9> H{Groc+RR(,c' );
define( 'SECURE_AUTH_SALT', 'g`;h:_IG-gL+#<{bkS`M&Z)9k|I&ioYvEQGROc;fb.,1jL[k[9p7hNCZ;^%=f8J:' );
define( 'LOGGED_IN_SALT',   'Sr%59)<{*D9x*otWE_n2<r.ksR7UR-A*t }:1x35O_q5D(vG!R(R;OIM3%D*P*S=' );
define( 'NONCE_SALT',       '>_q-Wy4;K Ix/aT;-l@(^Y:Z-#!S b[a(A0`#(#>.otDK/!fE-F]%}[Lg-nbptDa' );

/**#@-*/

/**
 * Prefisso tabella del database WordPress.
 *
 * È possibile avere installazioni multiple su di un unico database
 * fornendo a ciascuna installazione un prefisso univoco. Solo numeri, lettere e trattini bassi!
 */
$table_prefix = 'wp_';

/**
 * Per gli sviluppatori: modalità di debug di WordPress.
 *
 * Modificare questa voce a TRUE per abilitare la visualizzazione degli avvisi durante lo sviluppo
 * È fortemente raccomandato agli svilupaptori di temi e plugin di utilizare
 * WP_DEBUG all’interno dei loro ambienti di sviluppo.
 *
 * Per informazioni sulle altre costanti che possono essere utilizzate per il debug,
 * leggi la documentazione
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Aggiungere qualsiasi valore personalizzato tra questa riga e la riga "Finito, interrompere le modifiche". */



/* Finito, interrompere le modifiche! Buona pubblicazione. */

/** Path assoluto alla directory di WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Imposta le variabili di WordPress ed include i file. */
require_once ABSPATH . 'wp-settings.php';
define('FS_METHOD', 'direct');
